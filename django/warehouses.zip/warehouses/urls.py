from django.urls import path
from . import views

urlpatterns = [
    path('warehouses/list', views.warehouse_get_list)
]